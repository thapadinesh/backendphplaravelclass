<?php
$servername = "localhost:3308"; // "localhost"
$username = "root";
$password = ""; 
$dbname = "backendclass";

$conn = new mysqli($servername,$username,$password,$dbname);

// if($conn)
// {
//     echo "Database Connected Successfully.";
// }
?>